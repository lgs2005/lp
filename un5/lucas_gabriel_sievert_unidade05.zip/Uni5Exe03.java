public class Uni5Exe03 {
    public static void main(String[] args) {
        double soma = 0;
        for (int i = 1; i <= 100; i++) {
            soma += 1.0/i;
        }
        System.out.println(soma);
    }
}
