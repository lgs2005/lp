public class Uni5Exe11 {
    public static void main(String[] args) {
        int total = 0;
        for (int i = 0; i < 16; i++) {
            total += Math.pow(3, i);
        }
        System.out.println(total);
    }
}
